const web = document.getElementById('web');
const appdevelopment = document.getElementById('appdevelopment');
const javascript = document.getElementById('javascript')
const wordpress = document.getElementById('wordpress')
const navEl = document.getElementsByTagName('nav')[0];
const bar = document.querySelector('.fa-bars')
const times = document.querySelector('.times')
const navLink = document.querySelector('.nav-link')
const links = document.querySelectorAll('.nav-link a')
const spans = document.querySelectorAll('#span');



function displayBlock() {
   spans.forEach((span) => {
      span.style.transform = 'scale(1)';
   })
}

function animateStart() {
   web.style.animation = 'web 700ms forwards';
   appdevelopment.style.animation = 'appdevelopment 1000ms forwards';
   javascript.style.animation = 'javascript 1500ms forwards';
   wordpress.style.animation = 'wordpress 2s forwards';
}

// window.onscroll = function () {
//    myFunction()
// }

// function myFunction() {
//    const top = document.documentElement.scrollTop;
//    if(top >= 2040) {
//          setTimeout(() => {
//             animateStart();
//          }, 150);
   
//          setTimeout(() => {
//             displayBlock();
//          },1500)
//    }
//    if (top >= 300) {
//       navEl.classList.add('sticky')
//    }
//    if (top <= 300) {
//       navEl.classList.remove('sticky')
//    }
// }


// Responsive Js 

var a = window.matchMedia("(min-width: 480px)")
function mediaQueryOne(a) {
 
   if(a.matches) {
      window.onscroll = function () {
         myFunctionOne()
      }
      
      function myFunctionOne() {
         const top = document.documentElement.scrollTop;
         if(top >= 3400) {
            setTimeout( () => {
               animateStart();
            },150);
            setTimeout(() => {
               displayBlock();
            },1200)
         }
      }
   }
}
a.addListener(mediaQueryOne);
mediaQueryOne(a)


// Media Query Two 
var b = window.matchMedia("(min-width: 576px)")
function mediaQueryTwo(b) {
   if(b.matches) {
      window.onscroll = function () {
         myFunctionTwo()
      }
      function myFunctionTwo() {
         const top = document.documentElement.scrollTop;
         if(top >= 4060) {
            setTimeout( () => {
               animateStart();
            },150);
            setTimeout(() => {
               displayBlock();
            },1200)
         }
      }
   }
}
b.addListener(mediaQueryTwo);
mediaQueryTwo(b)


// Media Query Three 
var c = window.matchMedia("(min-width: 768px)")
function mediaQueryThree(c) {
   if(c.matches) {
      window.onscroll = function () {
         myFunctionThree()
      }
      function myFunctionThree() {
         const top = document.documentElement.scrollTop;
         if(top >= 2480) {
            setTimeout( () => {
               animateStart();
            },150);
            setTimeout(() => {
               displayBlock();
            },1200)
         }
         if (top >= 300) {
            navEl.classList.add('sticky');
         } else {
            navEl.classList.remove('sticky');
         }
      }
   }
}
c.addListener(mediaQueryThree);
mediaQueryThree(c)



// Media Query Four 
var d = window.matchMedia("(min-width: 900px)")
function mediaQueryFour(d) {
   if(d.matches) {
      window.onscroll = function () {
         myFunctionFour()
      }
      function myFunctionFour() {
         const top = document.documentElement.scrollTop;
         if(top >= 2500) {
            setTimeout( () => {
               animateStart();
            },150);
            setTimeout(() => {
               displayBlock();
            },1200)
         }
         if (top >= 300) {
            navEl.classList.add('sticky');
         } else {
            navEl.classList.remove('sticky');
         }
      }
   }
}
d.addListener(mediaQueryFour);
mediaQueryFour(d)



// Media  Query Five 
var e = window.matchMedia("(min-width: 1200px)")
function mediaQueryFive(e) {
   if(e.matches) {
      window.onscroll = function () {
         myfunctionFive()
      }
      function myfunctionFive() {
         const top = document.documentElement.scrollTop;
         if(top >= 2248) {
            setTimeout( () => {
               animateStart();
            },150);
            setTimeout(() => {
               displayBlock();
            },1200)
         }
         if (top >= 300) {
            navEl.classList.add('sticky');
         } else {
            navEl.classList.remove('sticky');
         }
      }
   }
}
e.addListener(mediaQueryFive);
mediaQueryFive(e)






// Responsive Navbar 
bar.addEventListener('click', () => {
   navLink.classList.add('open')
   bar.classList.add('close')
   times.classList.add('open')
})

times.addEventListener('click', () => {
   navLink.classList.remove('open')
   bar.classList.remove('close')
   times.classList.remove('open')
})

links.forEach((link) => {
   link.addEventListener('click', () => {
      setTimeout(() => {
         navLink.classList.remove('open')
      }, 50);

      bar.classList.remove('close')
      times.classList.remove('open')
   })
})


// Mixit Up 
$(document).ready(function () {
   var mixer = mixitup('.container1');
});



// Active Class Adding 
const link = document.querySelectorAll('.link');



link.forEach(function(linkt) {
   linkt.addEventListener('click', function(){
      var current = document.getElementsByClassName('active');
      current[0].className = current[0].className.replace(' active',' ');
      this.className += ' active';
   })
});